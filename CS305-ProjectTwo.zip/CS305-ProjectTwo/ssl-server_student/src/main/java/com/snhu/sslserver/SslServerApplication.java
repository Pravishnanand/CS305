package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @RestController
    public static class ChecksumController {

        @GetMapping("/checksum")
        public String generateChecksum() {
            try {
                // Unique data string
                String data = "Hello World Check Sum!";
    
                // Your name
                String name = "Pravishna Nand";
    
                // Calculate SHA-256 checksum
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));
    
                // Convert bytes to hexadecimal representation
                StringBuilder hexChecksum = new StringBuilder();
                for (byte hashByte : hashBytes) {
                    hexChecksum.append(String.format("%02x", hashByte));
                }
    
                // Construct the response
                String response = "Data: " + data + "\n";
                response += "Name: " + name + "\n";
                response += "Cipher Algorithm Used: SHA-256\n";
                response += "Checksum: " + hexChecksum.toString();
    
                return response;
            } catch (NoSuchAlgorithmException e) {
                return "Error: SHA-256 algorithm not available.";
            }
        }
    }
}